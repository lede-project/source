# uwe5622_driver

uwe5622的内核驱动

从[linux-orangepi](https://github.com/orangepi-xunlong/linux-orangepi/tree/orange-pi-6.6-rk35xx)中复制了6.6版本，升级到了6.11

~~买开发板之前一定要确认关键驱动有没有进内核主线~~